function sam() {
    document.querySelector(".container-second").classList.toggle('change');
}